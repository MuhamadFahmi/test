package main

import "fmt"
import "bitbucket.org/pkg/inflect"

func main() {
	i := inflect.Rule{}
	fmt.Println(i)
}
