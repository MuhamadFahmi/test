package main

import "fmt"
import "github.com/hillu/go-yara"

func main() {
	fmt.Println(yara.Rules{})
}
