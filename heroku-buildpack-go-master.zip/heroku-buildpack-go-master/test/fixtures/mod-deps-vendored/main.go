package main

import (
	"fmt"

	"github.com/gorilla/mux"
)

func main() {
	fmt.Println(mux.ErrNotFound)
}
