package sub

func Hello() string {
	return "hello"
}
